package com.akmod.item;

import com.akmod.AKMod;
import com.akmod.ModItems;
import com.akmod.ModSounds;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import javax.annotation.Nullable;
import java.util.List;

public class ItemAK47 extends Item {
    public static final int MAG_SIZE = 30;
    /** Тактическая перезарядка (патрон в патроннике): 2.4 c */
    public static final int RELOAD_TICKS = 48;
    /** Перезарядка с пустым магазином + досылание затвора: 3.1 c */
    public static final int RELOAD_EMPTY_TICKS = 62;

    public ItemAK47() {
        setUnlocalizedName(AKMod.MODID + ".ak47");
        setRegistryName(AKMod.MODID, "ak47");
        setMaxStackSize(1);
        setCreativeTab(CreativeTabs.COMBAT);
    }

    // ---------- NBT-помощники ----------
    public static NBTTagCompound tag(ItemStack s) {
        if (!s.hasTagCompound()) s.setTagCompound(new NBTTagCompound());
        return s.getTagCompound();
    }

    public static int getAmmo(ItemStack s) {
        return s.hasTagCompound() ? s.getTagCompound().getInteger("ammo") : 0;
    }

    public static void setAmmo(ItemStack s, int a) {
        tag(s).setInteger("ammo", a);
    }

    public static boolean isReloading(ItemStack s) {
        return s.hasTagCompound() && s.getTagCompound().getLong("reloadEnd") > 0;
    }

    public static int countAmmo(EntityPlayer p) {
        int n = 0;
        for (ItemStack s : p.inventory.mainInventory) if (s.getItem() == ModItems.AMMO) n += s.getCount();
        for (ItemStack s : p.inventory.offHandInventory) if (s.getItem() == ModItems.AMMO) n += s.getCount();
        return n;
    }

    private static boolean consumeAmmo(EntityPlayer p) {
        for (ItemStack s : p.inventory.mainInventory) {
            if (s.getItem() == ModItems.AMMO) { s.shrink(1); return true; }
        }
        for (ItemStack s : p.inventory.offHandInventory) {
            if (s.getItem() == ModItems.AMMO) { s.shrink(1); return true; }
        }
        return false;
    }

    // ---------- Перезарядка (только сервер) ----------
    public static void tryReload(EntityPlayer p, ItemStack stack) {
        if (isReloading(stack)) return;
        int ammo = getAmmo(stack);
        if (ammo > MAG_SIZE) return; // уже полный магазин + патрон в патроннике
        if (!p.capabilities.isCreativeMode && countAmmo(p) <= 0) {
            p.sendStatusMessage(new TextComponentTranslation("message.akmod.no_ammo"), true);
            return;
        }
        boolean empty = ammo <= 0;
        long now = p.world.getTotalWorldTime();
        NBTTagCompound t = tag(stack);
        t.setLong("reloadStart", now);
        t.setLong("reloadEnd", now + (empty ? RELOAD_EMPTY_TICKS : RELOAD_TICKS));
        t.setBoolean("reloadEmpty", empty);
    }

    private static void cancelReload(ItemStack stack) {
        NBTTagCompound t = stack.getTagCompound();
        if (t == null) return;
        t.removeTag("reloadStart");
        t.removeTag("reloadEnd");
        t.removeTag("reloadEmpty");
    }

    private static void play(EntityPlayer p, SoundEvent s) {
        p.world.playSound(null, p.posX, p.posY, p.posZ, s, SoundCategory.PLAYERS, 1.0F, 1.0F);
    }

    @Override
    public void onUpdate(ItemStack stack, World world, Entity entity, int slot, boolean selected) {
        if (world.isRemote || !(entity instanceof EntityPlayer) || !isReloading(stack)) return;
        EntityPlayer p = (EntityPlayer) entity;
        if (!selected) { // сменил слот - перезарядка прервана
            cancelReload(stack);
            return;
        }
        NBTTagCompound t = stack.getTagCompound();
        long now = world.getTotalWorldTime();
        long elapsed = now - t.getLong("reloadStart");
        boolean empty = t.getBoolean("reloadEmpty");

        if (elapsed == 12) play(p, ModSounds.MAG_OUT);
        if (elapsed == 28) play(p, ModSounds.MAG_IN);
        if (empty && elapsed == 46) play(p, ModSounds.BOLT);

        if (now >= t.getLong("reloadEnd")) {
            int ammo = getAmmo(stack);
            if (!p.capabilities.isCreativeMode && !consumeAmmo(p)) {
                cancelReload(stack);
                return;
            }
            setAmmo(stack, ammo > 0 ? MAG_SIZE + 1 : MAG_SIZE);
            cancelReload(stack);
        }
    }

    // ---------- Оружие не ломает блоки и не бьёт как меч ----------
    @Override
    public boolean onEntitySwing(EntityLivingBase entity, ItemStack stack) {
        return true;
    }

    @Override
    public boolean onLeftClickEntity(ItemStack stack, EntityPlayer player, Entity entity) {
        return true;
    }

    @Override
    public boolean onBlockStartBreak(ItemStack itemstack, BlockPos pos, EntityPlayer player) {
        return true;
    }

    @Override
    public boolean canDestroyBlockInCreative(World world, BlockPos pos, ItemStack stack, EntityPlayer player) {
        return false;
    }

    @Override
    public float getDestroySpeed(ItemStack stack, IBlockState state) {
        return 0.0F;
    }

    @Override
    public boolean shouldCauseReequipAnimation(ItemStack oldStack, ItemStack newStack, boolean slotChanged) {
        return slotChanged || oldStack.getItem() != newStack.getItem();
    }

    @Override
    public boolean shouldCauseBlockBreakReset(ItemStack oldStack, ItemStack newStack) {
        return false;
    }

    @SideOnly(Side.CLIENT)
    @Override
    public void addInformation(ItemStack stack, @Nullable World world, List<String> tooltip, ITooltipFlag flag) {
        tooltip.add(I18n.format("tooltip.akmod.ammo", getAmmo(stack), MAG_SIZE));
        tooltip.add(I18n.format("tooltip.akmod.controls"));
    }
}
