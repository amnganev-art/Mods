package com.akmod.server;

import com.akmod.ModSounds;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

import java.util.List;
import java.util.Random;

/** Серверная баллистика: хитскан с разбросом, падением урона по дальности и попаданием в голову. */
public final class Ballistics {
    public static final double RANGE = 128.0D;
    public static final float DAMAGE = 7.0F;          // 3.5 сердца в корпус
    public static final float HEADSHOT_MULT = 2.0F;   // в голову x2
    private static final Random RAND = new Random();

    private Ballistics() {}

    private static Vec3d look(float pitch, float yaw) {
        float f = MathHelper.cos(-yaw * 0.017453292F - (float) Math.PI);
        float f1 = MathHelper.sin(-yaw * 0.017453292F - (float) Math.PI);
        float f2 = -MathHelper.cos(-pitch * 0.017453292F);
        float f3 = MathHelper.sin(-pitch * 0.017453292F);
        return new Vec3d(f1 * f2, f3, f * f2);
    }

    /** Разброс в градусах: от прицела, приседа, движения, прыжка и "раскачки" очереди. */
    public static float spread(EntityPlayerMP p, boolean aiming, int burst) {
        double dx = p.posX - p.lastTickPosX, dz = p.posZ - p.lastTickPosZ;
        double speed = Math.sqrt(dx * dx + dz * dz);
        float spread = aiming ? 0.25F : 2.0F;
        if (p.isSneaking()) spread *= 0.6F;
        if (speed > 0.04D) spread *= aiming ? 2.2F : 1.7F;
        if (!p.onGround) spread *= 3.0F;
        spread += Math.min(burst, 10) * 0.07F;
        return spread;
    }

    public static void fire(EntityPlayerMP p, boolean aiming, int burst) {
        World w = p.world;
        Vec3d eye = new Vec3d(p.posX, p.posY + p.getEyeHeight(), p.posZ);

        float spread = spread(p, aiming, burst);
        double ang = RAND.nextDouble() * Math.PI * 2.0D;
        double rad = Math.sqrt(RAND.nextDouble()) * spread;
        float yaw = p.rotationYaw + (float) (Math.cos(ang) * rad);
        float pitch = p.rotationPitch + (float) (Math.sin(ang) * rad);
        Vec3d dir = look(pitch, yaw);
        Vec3d end = eye.add(dir.x * RANGE, dir.y * RANGE, dir.z * RANGE);

        // 1) блок на пути
        RayTraceResult blockHit = w.rayTraceBlocks(eye, end, false, true, false);
        double maxDist = RANGE;
        Vec3d clipEnd = end;
        if (blockHit != null && blockHit.hitVec != null) {
            maxDist = blockHit.hitVec.distanceTo(eye);
            clipEnd = blockHit.hitVec;
        }

        // 2) ближайшая сущность на пути
        Entity target = null;
        Vec3d targetVec = null;
        double best = maxDist;
        AxisAlignedBB sweep = p.getEntityBoundingBox().expand(dir.x * RANGE, dir.y * RANGE, dir.z * RANGE).grow(1.0D);
        List<Entity> list = w.getEntitiesWithinAABBExcludingEntity(p, sweep);
        for (Entity e : list) {
            if (e == null || !e.canBeCollidedWith()) continue;
            AxisAlignedBB bb = e.getEntityBoundingBox().grow(e.getCollisionBorderSize() + 0.05D);
            RayTraceResult r = bb.calculateIntercept(eye, clipEnd);
            if (r != null && r.hitVec != null) {
                double d = eye.distanceTo(r.hitVec);
                if (d < best) {
                    best = d;
                    target = e;
                    targetVec = r.hitVec;
                }
            }
        }

        // дульный дым
        if (w instanceof WorldServer) {
            Vec3d muzzle = eye.add(dir.x * 1.0D, dir.y * 1.0D - 0.12D, dir.z * 1.0D);
            ((WorldServer) w).spawnParticle(EnumParticleTypes.SMOKE_NORMAL, muzzle.x, muzzle.y, muzzle.z, 2, 0.02D, 0.02D, 0.02D, 0.01D);
        }

        if (target != null) {
            hitEntity(p, target, targetVec, best);
        } else if (blockHit != null && blockHit.typeOfHit == RayTraceResult.Type.BLOCK) {
            hitBlock(w, p, blockHit);
        }
    }

    private static void hitEntity(EntityPlayerMP shooter, Entity target, Vec3d hit, double dist) {
        float dmg = DAMAGE;
        // падение урона: после 60 м - линейно до 60%
        if (dist > 60.0D) dmg *= 1.0F - 0.4F * (float) Math.min(1.0D, (dist - 60.0D) / 60.0D);

        boolean head = false;
        if (target instanceof EntityLivingBase && hit.y >= target.posY + target.height * 0.82D) {
            head = true;
            dmg *= HEADSHOT_MULT;
        }

        DamageSource src = new EntityDamageSource("akmod.bullet", shooter).setProjectile();
        target.hurtResistantTime = 0; // чтобы очередь не гасилась неуязвимостью после урона
        target.attackEntityFrom(src, dmg);

        shooter.world.playSound(null, shooter.posX, shooter.posY, shooter.posZ,
                SoundEvents.ENTITY_ARROW_HIT_PLAYER, SoundCategory.PLAYERS, 0.4F, head ? 1.7F : 1.2F);

        if (shooter.world instanceof WorldServer) {
            ((WorldServer) shooter.world).spawnParticle(EnumParticleTypes.CRIT, hit.x, hit.y, hit.z, head ? 8 : 3, 0.1D, 0.1D, 0.1D, 0.1D);
        }
    }

    private static void hitBlock(World w, EntityPlayerMP shooter, RayTraceResult r) {
        BlockPos pos = r.getBlockPos();
        IBlockState st = w.getBlockState(pos);
        Vec3d v = r.hitVec;
        if (w instanceof WorldServer) {
            ((WorldServer) w).spawnParticle(EnumParticleTypes.BLOCK_CRACK, v.x, v.y, v.z, 10, 0.05D, 0.05D, 0.05D, 0.12D, Block.getStateId(st));
            ((WorldServer) w).spawnParticle(EnumParticleTypes.SMOKE_NORMAL, v.x, v.y, v.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        SoundType type = st.getBlock().getSoundType(st, w, pos, shooter);
        w.playSound(null, v.x, v.y, v.z, type.getBreakSound(), SoundCategory.BLOCKS, 0.6F, 1.5F);
    }

    public static void playShot(EntityPlayerMP p) {
        p.world.playSound(null, p.posX, p.posY, p.posZ, ModSounds.SHOT, SoundCategory.PLAYERS,
                5.0F, 0.96F + RAND.nextFloat() * 0.08F);
    }
}
