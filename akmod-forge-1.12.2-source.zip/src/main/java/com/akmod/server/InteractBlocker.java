package com.akmod.server;

import com.akmod.AKMod;
import com.akmod.ModItems;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * С автоматом в руке ЛКМ - стрельба, ПКМ - прицел. Поэтому отключаем ломание блоков,
 * установку блоков и взаимодействие (сундуки, жители и т.д.), чтобы они не мешали.
 * Чтобы открыть сундук - просто переключись на другой слот.
 */
@Mod.EventBusSubscriber(modid = AKMod.MODID)
public class InteractBlocker {
    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent e) {
        if (e.getEntityPlayer() == null) return;
        if (e.getEntityPlayer().getHeldItemMainhand().getItem() != ModItems.AK47) return;
        if (e.isCancelable()) e.setCanceled(true);
    }
}
