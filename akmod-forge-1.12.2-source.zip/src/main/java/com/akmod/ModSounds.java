package com.akmod;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;

public class ModSounds {
    public static final SoundEvent SHOT = make("ak_shot");
    public static final SoundEvent DRY = make("ak_dry");
    public static final SoundEvent MAG_OUT = make("ak_mag_out");
    public static final SoundEvent MAG_IN = make("ak_mag_in");
    public static final SoundEvent BOLT = make("ak_bolt");

    private static SoundEvent make(String name) {
        ResourceLocation rl = new ResourceLocation(AKMod.MODID, name);
        return new SoundEvent(rl).setRegistryName(rl);
    }
}
