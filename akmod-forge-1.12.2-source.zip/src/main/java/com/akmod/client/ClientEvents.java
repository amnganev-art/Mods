package com.akmod.client;

import com.akmod.AKMod;
import com.akmod.ModItems;
import com.akmod.item.ItemAK47;
import com.akmod.net.PacketInput;
import com.akmod.net.PacketReload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderSpecificHandEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import org.lwjgl.input.Keyboard;

import java.util.Random;

/**
 * Весь клиент: ввод (ЛКМ - огонь, ПКМ - прицел, R - перезарядка), отдача камеры,
 * анимации оружия от первого лица (прицеливание, отдача, перезарядка, бег), FOV, HUD.
 */
@Mod.EventBusSubscriber(modid = AKMod.MODID, value = Side.CLIENT)
public class ClientEvents {
    public static final KeyBinding RELOAD = new KeyBinding("key.akmod.reload", Keyboard.KEY_R, "key.categories.akmod");

    private static final Random RAND = new Random();

    // ===== ПОЗЫ ОРУЖИЯ (подстраивай под вкус) =====
    private static final float SCALE = 0.5F;
    private static final float HIP_X = 0.26F, HIP_Y = -0.20F, HIP_Z = -0.50F;     // от бедра
    private static final float ADS_X = 0.00F, ADS_Y = -0.131F, ADS_Z = -0.19F;    // у глаза (мушка по центру)
    private static final float ADS_FOV_MULT = 0.78F;                              // приближение при прицеливании
    private static final float ADS_SENS_MULT = 0.65F;                             // чувствительность мыши при прицеле

    // ===== состояние =====
    private static boolean sentTrigger, sentAim, aiming;
    private static float aim, prevAim, sprint, prevSprint, kick, prevKick, shake, prevShake;
    private static float pendingPitch, pendingYaw, recoverPitch;
    private static int sinceShot = 100, flash;
    private static float savedSens = -1F;

    private static ItemStack bodyStack, magStack, flashStack;

    // =====================================================================
    //  ТИК: ввод, отдача, сглаживание анимаций
    // =====================================================================
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP p = mc.player;

        prevAim = aim; prevSprint = sprint; prevKick = kick; prevShake = shake;

        boolean holding = p != null && mc.world != null && p.getHeldItemMainhand().getItem() == ModItems.AK47;
        boolean canControl = holding && mc.currentScreen == null && mc.inGameHasFocus;
        ItemStack held = holding ? p.getHeldItemMainhand() : ItemStack.EMPTY;
        boolean reloading = holding && ItemAK47.isReloading(held);

        boolean wantTrigger = canControl && mc.gameSettings.keyBindAttack.isKeyDown() && !p.isSprinting();
        boolean wantAim = canControl && mc.gameSettings.keyBindUseItem.isKeyDown() && !reloading && !p.isSprinting();
        aiming = wantAim;

        // чувствительность мыши при прицеливании (безопасно восстанавливаем)
        if (wantAim) {
            if (savedSens < 0F) savedSens = mc.gameSettings.mouseSensitivity;
            mc.gameSettings.mouseSensitivity = savedSens * ADS_SENS_MULT;
        } else if (savedSens >= 0F) {
            mc.gameSettings.mouseSensitivity = savedSens;
            savedSens = -1F;
        }

        if (p == null || mc.world == null) {
            sentTrigger = false; sentAim = false;
            pendingPitch = pendingYaw = recoverPitch = 0F;
            aim = prevAim = 0F;
            return;
        }

        // отправка состояния спуска/прицела на сервер только при изменении
        if (wantTrigger != sentTrigger || wantAim != sentAim) {
            sentTrigger = wantTrigger;
            sentAim = wantAim;
            AKMod.NET.sendToServer(new PacketInput(wantTrigger, wantAim));
        }

        // клавиша перезарядки
        while (RELOAD.isPressed()) {
            if (canControl) AKMod.NET.sendToServer(new PacketReload());
        }

        // сглаживание анимаций
        aim = MathHelper.clamp(aim + (wantAim ? 0.2F : -0.2F), 0F, 1F);
        sprint += (((holding && p.isSprinting()) ? 1F : 0F) - sprint) * 0.3F;
        kick *= 0.55F;
        shake *= 0.6F;
        if (flash > 0) flash--;
        sinceShot++;

        // применение отдачи к камере
        if (holding) {
            if (Math.abs(pendingPitch) > 0.001F || Math.abs(pendingYaw) > 0.001F) {
                float ap = pendingPitch * 0.6F, ay = pendingYaw * 0.6F;
                pendingPitch -= ap;
                pendingYaw -= ay;
                p.rotationPitch = MathHelper.clamp(p.rotationPitch - ap, -90F, 90F);
                p.prevRotationPitch = MathHelper.clamp(p.prevRotationPitch - ap, -90F, 90F);
                p.rotationYaw += ay;
                p.prevRotationYaw += ay;
            } else if (sinceShot > 3 && recoverPitch > 0.02F) {
                // после очереди прицел частично возвращается вниз (70% отдачи), 30% нужно компенсировать мышью
                float r = Math.min(recoverPitch, recoverPitch * 0.12F + 0.02F);
                recoverPitch -= r;
                p.rotationPitch = MathHelper.clamp(p.rotationPitch + r, -90F, 90F);
                p.prevRotationPitch = MathHelper.clamp(p.prevRotationPitch + r, -90F, 90F);
            }
        } else {
            pendingPitch = pendingYaw = recoverPitch = 0F;
        }
    }

    /** Сервер подтвердил выстрел: добавляем отдачу. Сидя (Shift) - отдача сильно меньше. */
    public static void onShot(int burstIndex) {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP p = mc.player;
        if (p == null) return;

        float mult = 1F;
        if (aiming) mult *= 0.8F;
        if (p.isSneaking()) mult *= 0.45F;                       // КОНТРОЛИРУЕМАЯ отдача сидя
        if (!p.onGround) mult *= 1.8F;
        else if (p.movementInput != null && (p.movementInput.moveForward != 0F || p.movementInput.moveStrafe != 0F)) mult *= 1.25F;

        int i = Math.min(burstIndex, 12);
        float kp = (0.85F + 0.14F * Math.min(i, 8)) * mult;                                   // вверх, нарастает
        float ky = ((float) Math.sin(i * 0.85D) * 0.28F + (RAND.nextFloat() - 0.5F) * 0.25F) * mult; // уход вбок

        pendingPitch += kp;
        pendingYaw += ky;
        recoverPitch += kp * 0.7F;
        kick = 1F;
        shake = Math.max(shake, 1F * (p.isSneaking() ? 0.5F : 1F));
        flash = 1;
        sinceShot = 0;
    }

    // =====================================================================
    //  ОТРИСОВКА ОРУЖИЯ ОТ ПЕРВОГО ЛИЦА
    // =====================================================================
    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static float smooth01(float x) {
        x = MathHelper.clamp(x, 0F, 1F);
        return x * x * (3F - 2F * x);
    }

    @SubscribeEvent
    public static void onRenderHand(RenderSpecificHandEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP p = mc.player;
        if (p == null || p.getHeldItemMainhand().getItem() != ModItems.AK47) return;
        e.setCanceled(true);                              // прячем ванильную руку/предмет
        if (e.getHand() != EnumHand.MAIN_HAND) return;

        if (bodyStack == null) {
            bodyStack = new ItemStack(ModItems.BODY);
            magStack = new ItemStack(ModItems.MAG);
            flashStack = new ItemStack(ModItems.FLASH);
        }

        float pt = e.getPartialTicks();
        ItemStack gun = p.getHeldItemMainhand();
        float a = smooth01(lerp(prevAim, aim, pt));
        float sp = lerp(prevSprint, sprint, pt);
        float k = lerp(prevKick, kick, pt);

        // ---- состояние перезарядки (из NBT оружия) ----
        boolean rel = ItemAK47.isReloading(gun);
        float el = 0F, total = 1F;
        boolean empty = false;
        if (rel) {
            NBTTagCompound t = gun.getTagCompound();
            long start = t.getLong("reloadStart");
            total = (float) (t.getLong("reloadEnd") - start);
            el = (float) (mc.world.getTotalWorldTime() - start) + pt;
            empty = t.getBoolean("reloadEmpty");
        }

        float tilt = 0F, magOff = 0F, pull = 0F;
        boolean magVisible = true;
        if (rel) {
            tilt = Math.min(smooth01(el / 6F), smooth01((total - el) / 8F));
            if (el >= 8F && el < 14F) magOff = 0.9F * smooth01((el - 8F) / 6F);      // магазин вынимается вниз
            else if (el >= 14F && el < 22F) magVisible = false;                        // новый магазин достаётся
            else if (el >= 22F && el < 30F) magOff = 0.9F * (1F - smooth01((el - 22F) / 8F)); // вставляется снизу
            if (empty) {
                float b = el - 44F;                                                    // передёргивание затвора
                if (b > 0F && b < 6F) pull = (float) Math.sin(b / 6F * Math.PI);
            }
        }

        // ---- покачивание при ходьбе ----
        float walk = -(p.distanceWalkedModified + (p.distanceWalkedModified - p.prevDistanceWalkedModified) * pt) * (float) Math.PI;
        float cy = lerp(p.prevCameraYaw, p.cameraYaw, pt);
        float bobAmp = 0.03F * (1F - 0.85F * a);
        float bobX = (float) Math.sin(walk) * cy * bobAmp;
        float bobY = -Math.abs((float) Math.cos(walk)) * cy * bobAmp;

        // ---- итоговая поза ----
        float x = lerp(HIP_X, ADS_X, a) + bobX;
        float y = lerp(HIP_Y, ADS_Y, a) + bobY;
        float z = lerp(HIP_Z, ADS_Z, a);

        x += sp * 0.06F - tilt * 0.08F;
        y += -sp * 0.14F - tilt * 0.06F;
        z += k * (0.07F - 0.04F * a) + pull * 0.03F;
        y += k * 0.008F;

        float yawRot = 5F * (1F - a) + 28F * sp;
        float pitchRot = k * (3.2F - 1.6F * a) + tilt * 9F - sp * 6F;
        float rollRot = -24F * tilt;

        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, z);
        GlStateManager.rotate(yawRot, 0F, 1F, 0F);
        GlStateManager.rotate(pitchRot, 1F, 0F, 0F);
        GlStateManager.rotate(rollRot, 0F, 0F, 1F);
        GlStateManager.rotate(90F, 0F, 1F, 0F);   // ствол модели (+X) -> вперёд
        GlStateManager.scale(SCALE, SCALE, SCALE);

        GlStateManager.enableRescaleNormal();
        mc.getItemRenderer().renderItemSide(p, bodyStack, ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND, false);

        if (magVisible) {
            GlStateManager.pushMatrix();
            GlStateManager.translate(0F, -magOff, 0F);
            mc.getItemRenderer().renderItemSide(p, magStack, ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND, false);
            GlStateManager.popMatrix();
        }

        if (flash > 0 && !rel) {
            float lx = OpenGlHelper.lastBrightnessX, ly = OpenGlHelper.lastBrightnessY;
            GlStateManager.disableLighting();
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240F, 240F);
            mc.getItemRenderer().renderItemSide(p, flashStack, ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND, false);
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, lx, ly);
            GlStateManager.enableLighting();
        }

        GlStateManager.disableRescaleNormal();
        GlStateManager.popMatrix();
    }

    // =====================================================================
    //  FOV, тряска камеры, HUD
    // =====================================================================
    @SubscribeEvent
    public static void onFov(EntityViewRenderEvent.FOVModifier e) {
        float a = smooth01(lerp(prevAim, aim, (float) e.getRenderPartialTicks()));
        if (a > 0F) e.setFOV(e.getFOV() * lerp(1F, ADS_FOV_MULT, a));
    }

    @SubscribeEvent
    public static void onCamera(EntityViewRenderEvent.CameraSetup e) {
        float s = lerp(prevShake, shake, (float) e.getRenderPartialTicks());
        if (s > 0.01F) {
            e.setRoll(e.getRoll() + (RAND.nextFloat() - 0.5F) * 0.9F * s);
            e.setPitch(e.getPitch() + (RAND.nextFloat() - 0.5F) * 0.3F * s);
        }
    }

    @SubscribeEvent
    public static void onOverlayPre(RenderGameOverlayEvent.Pre e) {
        // при прицеливании ванильный перекрестие не нужно - есть мушка
        if (e.getType() == RenderGameOverlayEvent.ElementType.CROSSHAIRS && aim > 0.5F) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onOverlayPost(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP p = mc.player;
        if (p == null || p.getHeldItemMainhand().getItem() != ModItems.AK47 || mc.gameSettings.hideGUI) return;

        ItemStack gun = p.getHeldItemMainhand();
        int ammo = ItemAK47.getAmmo(gun);
        int reserve = p.capabilities.isCreativeMode ? -1 : ItemAK47.countAmmo(p);

        String top = ItemAK47.isReloading(gun) ? I18n.format("hud.akmod.reloading") : String.valueOf(ammo);
        String bottom = reserve < 0 ? "\u221E" : "x" + reserve;
        int color = (ammo <= 5 && !ItemAK47.isReloading(gun)) ? 0xFF5555 : 0xFFFFFF;

        ScaledResolution res = e.getResolution();
        int w = res.getScaledWidth(), h = res.getScaledHeight();

        GlStateManager.pushMatrix();
        GlStateManager.scale(2F, 2F, 1F);
        int tw = mc.fontRenderer.getStringWidth(top);
        mc.fontRenderer.drawStringWithShadow(top, (w - 14) / 2F - tw, (h - 52) / 2F, color);
        GlStateManager.popMatrix();

        int bw = mc.fontRenderer.getStringWidth(bottom);
        mc.fontRenderer.drawStringWithShadow(bottom, w - 14 - bw, h - 34, 0xAAAAAA);
        mc.fontRenderer.drawStringWithShadow("AK-47", w - 14 - mc.fontRenderer.getStringWidth("AK-47"), h - 24, 0x888888);
    }
}
