package com.akmod.proxy;

public class CommonProxy {
    public void preInit() {}

    /** Вызывается на клиенте, когда сервер сообщил о выстреле (для отдачи). */
    public void onShot(int burstIndex) {}
}
