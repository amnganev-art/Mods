package com.akmod.net;

import com.akmod.AKMod;
import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Сервер -> клиент: выстрел произведён (номер выстрела в очереди) - клиент применяет отдачу. */
public class PacketShot implements IMessage {
    public int index;

    public PacketShot() {}

    public PacketShot(int index) {
        this.index = index;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        index = buf.readInt();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeInt(index);
    }

    public static class Handler implements IMessageHandler<PacketShot, IMessage> {
        @Override
        public IMessage onMessage(PacketShot m, MessageContext ctx) {
            AKMod.proxy.onShot(m.index);
            return null;
        }
    }
}
