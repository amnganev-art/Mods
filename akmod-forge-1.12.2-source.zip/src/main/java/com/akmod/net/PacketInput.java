package com.akmod.net;

import com.akmod.server.ServerEvents;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Клиент -> сервер: зажат ли спуск и прицел. */
public class PacketInput implements IMessage {
    public boolean trigger, aim;

    public PacketInput() {}

    public PacketInput(boolean trigger, boolean aim) {
        this.trigger = trigger;
        this.aim = aim;
    }

    @Override
    public void fromBytes(ByteBuf buf) {
        trigger = buf.readBoolean();
        aim = buf.readBoolean();
    }

    @Override
    public void toBytes(ByteBuf buf) {
        buf.writeBoolean(trigger);
        buf.writeBoolean(aim);
    }

    public static class Handler implements IMessageHandler<PacketInput, IMessage> {
        @Override
        public IMessage onMessage(final PacketInput m, MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().player;
            p.getServerWorld().addScheduledTask(() -> {
                ServerEvents.ShootState s = ServerEvents.state(p);
                s.trigger = m.trigger;
                s.aim = m.aim;
            });
            return null;
        }
    }
}
