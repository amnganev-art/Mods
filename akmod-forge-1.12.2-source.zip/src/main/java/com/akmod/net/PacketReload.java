package com.akmod.net;

import com.akmod.ModItems;
import com.akmod.item.ItemAK47;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Клиент -> сервер: нажата клавиша перезарядки. */
public class PacketReload implements IMessage {
    @Override public void fromBytes(ByteBuf buf) {}
    @Override public void toBytes(ByteBuf buf) {}

    public static class Handler implements IMessageHandler<PacketReload, IMessage> {
        @Override
        public IMessage onMessage(PacketReload m, MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().player;
            p.getServerWorld().addScheduledTask(() -> {
                ItemStack s = p.getHeldItemMainhand();
                if (s.getItem() == ModItems.AK47) ItemAK47.tryReload(p, s);
            });
            return null;
        }
    }
}
