package com.akmod;

import com.akmod.net.PacketInput;
import com.akmod.net.PacketReload;
import com.akmod.net.PacketShot;
import com.akmod.proxy.CommonProxy;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

@Mod(modid = AKMod.MODID, name = "AK-47 Mod", version = "1.0.0", acceptedMinecraftVersions = "[1.12.2]")
public class AKMod {
    public static final String MODID = "akmod";

    @SidedProxy(clientSide = "com.akmod.proxy.ClientProxy", serverSide = "com.akmod.proxy.CommonProxy")
    public static CommonProxy proxy;

    public static SimpleNetworkWrapper NET;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        NET = NetworkRegistry.INSTANCE.newSimpleChannel(MODID);
        NET.registerMessage(PacketInput.Handler.class, PacketInput.class, 0, Side.SERVER);
        NET.registerMessage(PacketReload.Handler.class, PacketReload.class, 1, Side.SERVER);
        NET.registerMessage(PacketShot.Handler.class, PacketShot.class, 2, Side.CLIENT);
        proxy.preInit();
    }
}
