package com.akmod;

import com.akmod.item.ItemAK47;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;

public class ModItems {
    public static final Item AK47 = new ItemAK47();

    /** Патроны: 1 предмет = 1 полный магазин на 30. */
    public static final Item AMMO = new Item()
            .setTranslationKey(AKMod.MODID + ".ammo_762")
            .setRegistryName(AKMod.MODID, "ammo_762")
            .setCreativeTab(CreativeTabs.COMBAT);

    // Невидимые "визуальные" предметы - только для отрисовки от первого лица
    public static final Item BODY = visual("ak47_body");
    public static final Item MAG = visual("ak47_mag");
    public static final Item FLASH = visual("ak47_flash");
    public static final Item LHAND = visual("ak47_lhand");

    private static Item visual(String name) {
        return new Item().setTranslationKey(AKMod.MODID + "." + name).setRegistryName(AKMod.MODID, name);
    }
}
