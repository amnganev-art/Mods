package com.akmod.server;

import com.akmod.AKMod;
import com.akmod.ModItems;
import com.akmod.ModSounds;
import com.akmod.item.ItemAK47;
import com.akmod.net.PacketShot;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.SoundCategory;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.PlayerEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Серверный цикл стрельбы: автоматический огонь 600 выстр./мин (каждые 2 тика). */
@Mod.EventBusSubscriber(modid = AKMod.MODID)
public class ServerEvents {
    public static final int FIRE_INTERVAL_TICKS = 2;

    public static class ShootState {
        public boolean trigger, aim, dry, semiLock;
        public long nextShot, lastShot;
        public int burst;
    }

    private static final Map<UUID, ShootState> STATES = new HashMap<>();

    public static ShootState state(EntityPlayerMP p) {
        ShootState s = STATES.get(p.getUniqueID());
        if (s == null) {
            s = new ShootState();
            STATES.put(p.getUniqueID(), s);
        }
        return s;
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        STATES.remove(e.player.getUniqueID());
    }

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != Side.SERVER) return;
        EntityPlayerMP p = (EntityPlayerMP) e.player;
        ShootState st = STATES.get(p.getUniqueID());
        if (st == null) return;

        ItemStack stack = p.getHeldItemMainhand();
        if (stack.getItem() != ModItems.AK47 || p.isSpectator() || p.isDead) {
            st.dry = false;
            return;
        }

        long now = p.world.getTotalWorldTime();
        if (now - st.lastShot > 6) st.burst = 0;

        if (!st.trigger) {
            st.dry = false;
            st.semiLock = false;
            return;
        }
        boolean semi = ItemAK47.isSemi(stack);
        if (semi && st.semiLock) return; // одиночный: один выстрел на одно нажатие
        if (ItemAK47.isReloading(stack) || p.isSprinting() || now < st.nextShot) return;

        int ammo = ItemAK47.getAmmo(stack);
        if (ammo <= 0) {
            if (!st.dry) {
                st.dry = true;
                p.world.playSound(null, p.posX, p.posY, p.posZ, ModSounds.DRY, SoundCategory.PLAYERS, 1.0F, 1.0F);
            }
            return;
        }

        ItemAK47.setAmmo(stack, ammo - 1);
        st.nextShot = now + FIRE_INTERVAL_TICKS;
        st.lastShot = now;
        st.burst++;
        if (semi) st.semiLock = true;

        Ballistics.playShot(p);
        Ballistics.fire(p, st.aim, st.burst);
        AKMod.NET.sendTo(new PacketShot(st.burst), p);
    }
}
