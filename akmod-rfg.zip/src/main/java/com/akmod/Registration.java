package com.akmod;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@Mod.EventBusSubscriber(modid = AKMod.MODID)
public class Registration {

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> e) {
        e.getRegistry().registerAll(ModItems.AK47, ModItems.AMMO, ModItems.BODY, ModItems.MAG, ModItems.FLASH, ModItems.LHAND);
    }

    @SubscribeEvent
    public static void registerSounds(RegistryEvent.Register<SoundEvent> e) {
        e.getRegistry().registerAll(ModSounds.SHOT, ModSounds.DRY, ModSounds.MAG_OUT, ModSounds.MAG_IN, ModSounds.BOLT);
    }

    @SideOnly(Side.CLIENT)
    @SubscribeEvent
    public static void registerModels(ModelRegistryEvent e) {
        Item[] all = {ModItems.AK47, ModItems.AMMO, ModItems.BODY, ModItems.MAG, ModItems.FLASH, ModItems.LHAND};
        for (Item i : all) {
            ModelLoader.setCustomModelResourceLocation(i, 0, new ModelResourceLocation(i.getRegistryName(), "inventory"));
        }
    }
}
