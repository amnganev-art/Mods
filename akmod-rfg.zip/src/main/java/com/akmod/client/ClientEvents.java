package com.akmod.client;

import com.akmod.AKMod;
import com.akmod.ModItems;
import com.akmod.item.ItemAK47;
import com.akmod.net.PacketFireMode;
import com.akmod.net.PacketInput;
import com.akmod.net.PacketReload;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.EnumHand;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderSpecificHandEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import org.lwjgl.input.Keyboard;

import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelPlayer;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.entity.RenderPlayer;
import org.lwjgl.BufferUtils;

import java.nio.FloatBuffer;
import java.util.Random;

/**
 * Весь клиент: ввод (ЛКМ - огонь, ПКМ - прицел, R - перезарядка), отдача камеры,
 * анимации оружия от первого лица (прицеливание, отдача, перезарядка, бег), FOV, HUD.
 */
@Mod.EventBusSubscriber(modid = AKMod.MODID, value = Side.CLIENT)
public class ClientEvents {
    public static final KeyBinding RELOAD = new KeyBinding("key.akmod.reload", Keyboard.KEY_R, "key.categories.akmod");
    public static final KeyBinding FIREMODE = new KeyBinding("key.akmod.firemode", Keyboard.KEY_B, "key.categories.akmod");

    private static final Random RAND = new Random();

    // ===== ПОЗЫ ОРУЖИЯ (подстраивай под вкус) =====
    private static final float SCALE = 0.5F;
    private static final float HIP_X = 0.16F, HIP_Y = -0.13F, HIP_Z = -0.46F;     // от бедра
    private static final float ADS_X = 0.00F, ADS_Y = -0.141F, ADS_Z = -0.2125F;    // у глаза (мушка по центру)
    // ===== РУКИ ИГРОКА (настоящие руки со скином) =====
    private static final float ARM_SCALE = 0.8F;
    // кисть в единицах модели (1/16 блока), направление плечо->кисть и направление ладони в системе оружия (X вперёд, Y вверх, Z вправо)
    private static final float[] R_HAND = {2.5F, 7.6F, 8.0F}, R_DIR = {0.60F, 0.75F, -0.40F}, R_PALM = {0F, 0F, -1F};
    private static final float[] L_HAND = {13.8F, 9.4F, 8.0F}, L_DIR = {0.55F, 0.75F, 0.35F}, L_PALM = {0F, 1F, 0F};

    private static final float ADS_FOV_MULT = 0.78F;                              // приближение при прицеливании
    private static final float ADS_SENS_MULT = 0.65F;                             // чувствительность мыши при прицеле

    // ===== состояние =====
    private static boolean sentTrigger, sentAim, aiming;
    private static float aim, prevAim, sprint, prevSprint, kick, prevKick, shake, prevShake;
    private static float pendingPitch, pendingYaw;
    private static int sinceShot = 100, flash;
    private static float savedSens = -1F;

    private static ItemStack bodyStack, magStack, flashStack;
    private static final FloatBuffer MBUF = BufferUtils.createFloatBuffer(16);

    // =====================================================================
    //  ТИК: ввод, отдача, сглаживание анимаций
    // =====================================================================
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP p = mc.player;

        prevAim = aim; prevSprint = sprint; prevKick = kick; prevShake = shake;

        boolean holding = p != null && mc.world != null && p.getHeldItemMainhand().getItem() == ModItems.AK47;
        boolean canControl = holding && mc.currentScreen == null && mc.inGameHasFocus;
        ItemStack held = holding ? p.getHeldItemMainhand() : ItemStack.EMPTY;
        boolean reloading = holding && ItemAK47.isReloading(held);

        boolean wantTrigger = canControl && mc.gameSettings.keyBindAttack.isKeyDown() && !p.isSprinting();
        boolean wantAim = canControl && mc.gameSettings.keyBindUseItem.isKeyDown() && !reloading && !p.isSprinting();
        aiming = wantAim;

        // чувствительность мыши при прицеливании (безопасно восстанавливаем)
        if (wantAim) {
            if (savedSens < 0F) savedSens = mc.gameSettings.mouseSensitivity;
            mc.gameSettings.mouseSensitivity = savedSens * ADS_SENS_MULT;
        } else if (savedSens >= 0F) {
            mc.gameSettings.mouseSensitivity = savedSens;
            savedSens = -1F;
        }

        if (p == null || mc.world == null) {
            sentTrigger = false; sentAim = false;
            pendingPitch = pendingYaw = 0F;
            aim = prevAim = 0F;
            return;
        }

        // отправка состояния спуска/прицела на сервер только при изменении
        if (wantTrigger != sentTrigger || wantAim != sentAim) {
            sentTrigger = wantTrigger;
            sentAim = wantAim;
            AKMod.NET.sendToServer(new PacketInput(wantTrigger, wantAim));
        }

        // клавиша перезарядки
        while (RELOAD.isPressed()) {
            if (canControl) AKMod.NET.sendToServer(new PacketReload());
        }

        while (FIREMODE.isPressed()) {
            if (canControl) AKMod.NET.sendToServer(new PacketFireMode());
        }

        // сглаживание анимаций
        aim = MathHelper.clamp(aim + (wantAim ? 0.2F : -0.2F), 0F, 1F);
        sprint += (((holding && p.isSprinting()) ? 1F : 0F) - sprint) * 0.3F;
        kick *= 0.55F;
        shake *= 0.6F;
        if (flash > 0) flash--;
        sinceShot++;

        // применение отдачи к камере
        if (holding) {
            if (Math.abs(pendingPitch) > 0.001F || Math.abs(pendingYaw) > 0.001F) {
                float ap = pendingPitch * 0.6F, ay = pendingYaw * 0.6F;
                pendingPitch -= ap;
                pendingYaw -= ay;
                p.rotationPitch = MathHelper.clamp(p.rotationPitch - ap, -90F, 90F);
                p.prevRotationPitch = MathHelper.clamp(p.prevRotationPitch - ap, -90F, 90F);
                p.rotationYaw += ay;
                p.prevRotationYaw += ay;
            }
            // камера после очереди НЕ возвращается вниз - отдачу гасит игрок мышью
        } else {
            pendingPitch = pendingYaw = 0F;
        }
    }

    /** Сервер подтвердил выстрел: добавляем отдачу. Сидя (Shift) - отдача сильно меньше. */
    public static void onShot(int burstIndex) {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP p = mc.player;
        if (p == null) return;

        float mult = 1F;
        if (aiming) mult *= 0.8F;
        if (p.isSneaking()) mult *= 0.45F;                       // КОНТРОЛИРУЕМАЯ отдача сидя
        if (!p.onGround) mult *= 1.8F;
        else if (p.movementInput != null && (p.movementInput.moveForward != 0F || p.movementInput.moveStrafe != 0F)) mult *= 1.25F;

        int i = Math.min(burstIndex, 12);
        float kp = (0.85F + 0.14F * Math.min(i, 8)) * mult;                                   // вверх, нарастает
        float ky = ((float) Math.sin(i * 0.85D) * 0.28F + (RAND.nextFloat() - 0.5F) * 0.25F) * mult; // уход вбок

        pendingPitch += kp;
        pendingYaw += ky;
        kick = 1F;
        shake = Math.max(shake, 1F * (p.isSneaking() ? 0.5F : 1F));
        flash = 1;
        sinceShot = 0;
    }

    // =====================================================================
    //  ОТРИСОВКА ОРУЖИЯ ОТ ПЕРВОГО ЛИЦА
    // =====================================================================
    private static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    private static float smooth01(float x) {
        x = MathHelper.clamp(x, 0F, 1F);
        return x * x * (3F - 2F * x);
    }

    @SubscribeEvent
    public static void onRenderHand(RenderSpecificHandEvent e) {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP p = mc.player;
        if (p == null || p.getHeldItemMainhand().getItem() != ModItems.AK47) return;
        e.setCanceled(true);                              // прячем ванильную руку/предмет
        if (e.getHand() != EnumHand.MAIN_HAND) return;

        if (bodyStack == null) {
            bodyStack = new ItemStack(ModItems.BODY);
            magStack = new ItemStack(ModItems.MAG);
            flashStack = new ItemStack(ModItems.FLASH);
        }

        float pt = e.getPartialTicks();
        ItemStack gun = p.getHeldItemMainhand();
        float a = smooth01(lerp(prevAim, aim, pt));
        float sp = lerp(prevSprint, sprint, pt);
        float k = lerp(prevKick, kick, pt);

        // ---- состояние перезарядки (из NBT оружия) ----
        boolean rel = ItemAK47.isReloading(gun);
        float el = 0F, total = 1F;
        boolean empty = false;
        if (rel) {
            NBTTagCompound t = gun.getTagCompound();
            long start = t.getLong("reloadStart");
            total = (float) (t.getLong("reloadEnd") - start);
            el = (float) (mc.world.getTotalWorldTime() - start) + pt;
            empty = t.getBoolean("reloadEmpty");
        }

        float tilt = 0F, magOff = 0F;
        float lhx = 0F, lhy = 0F, lhz = 0F;      // смещение левой руки в единицах модели (1/16 блока)
        boolean magVisible = true;
        if (rel) {
            tilt = Math.min(smooth01(el / 6F), smooth01((total - el) / 8F));
            if (el >= 8F && el < 14F) magOff = 0.9F * smooth01((el - 8F) / 6F);      // магазин вынимается вниз
            else if (el >= 14F && el < 22F) magVisible = false;                        // новый магазин достаётся
            else if (el >= 22F && el < 30F) magOff = 0.9F * (1F - smooth01((el - 22F) / 8F)); // вставляется снизу

            // левая рука: цевьё -> магазин -> (затвор при пустом) -> цевьё
            float grab = smooth01((el - 3F) / 4F);
            final float gx = -4.6F, gy = -2.5F, gz = 0F;        // рука на магазине
            final float bx = -4.8F, by = 2.4F, bz = 1.6F;       // рука на рукоятке затвора
            if (!empty) {
                float k2 = grab * (1F - smooth01((el - 30F) / 8F));
                lhx = gx * k2; lhy = gy * k2 - magOff * 16F * k2; lhz = gz * k2;
            } else {
                float toBolt = smooth01((el - 32F) / 6F);
                float back = smooth01((el - 50F) / 8F);
                float onMag = grab * (1F - toBolt);
                float onBolt = toBolt * (1F - back);
                float pullK = smooth01((el - 40F) / 6F) * (1F - smooth01((el - 46F) / 3F));
                lhx = gx * onMag + bx * onBolt - 3.5F * pullK * onBolt;
                lhy = gy * onMag - magOff * 16F * onMag + by * onBolt;
                lhz = gz * onMag + bz * onBolt;
            }
        }

        // ---- покачивание при ходьбе ----
        float walk = -(p.distanceWalkedModified + (p.distanceWalkedModified - p.prevDistanceWalkedModified) * pt) * (float) Math.PI;
        float cy = lerp(p.prevCameraYaw, p.cameraYaw, pt);
        float bobAmp = 0.03F * (1F - 0.85F * a);
        float bobX = (float) Math.sin(walk) * cy * bobAmp;
        float bobY = -Math.abs((float) Math.cos(walk)) * cy * bobAmp;

        // ---- итоговая поза ----
        float x = lerp(HIP_X, ADS_X, a) + bobX;
        float y = lerp(HIP_Y, ADS_Y, a) + bobY;
        float z = lerp(HIP_Z, ADS_Z, a);

        x += sp * 0.06F - tilt * 0.08F;
        y += -sp * 0.14F - tilt * 0.06F;
        z += k * (0.07F - 0.04F * a);
        y += k * 0.008F;

        float yawRot = 5F * (1F - a) + 28F * sp;
        float pitchRot = k * (3.2F - 1.6F * a) + tilt * 9F - sp * 6F;
        float rollRot = -24F * tilt;

        GlStateManager.pushMatrix();
        GlStateManager.translate(x, y, z);
        GlStateManager.rotate(yawRot, 0F, 1F, 0F);
        GlStateManager.rotate(pitchRot, 1F, 0F, 0F);
        GlStateManager.rotate(rollRot, 0F, 0F, 1F);
        GlStateManager.rotate(90F, 0F, 1F, 0F);   // ствол модели (+X) -> вперёд

        // ---- руки игрока (в системе оружия, без масштаба) ----
        renderArm(mc, p, true, R_HAND, 0F, 0F, 0F, R_DIR, R_PALM);
        renderArm(mc, p, false, L_HAND, lhx, lhy, lhz, L_DIR, L_PALM);

        GlStateManager.scale(SCALE, SCALE, SCALE);

        GlStateManager.enableRescaleNormal();
        mc.getItemRenderer().renderItemSide(p, bodyStack, ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND, false);

        if (magVisible) {
            GlStateManager.pushMatrix();
            GlStateManager.translate(0F, -magOff, 0F);
            mc.getItemRenderer().renderItemSide(p, magStack, ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND, false);
            GlStateManager.popMatrix();
        }

        if (flash > 0 && !rel) {
            float lx = OpenGlHelper.lastBrightnessX, ly = OpenGlHelper.lastBrightnessY;
            GlStateManager.disableLighting();
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 240F, 240F);
            mc.getItemRenderer().renderItemSide(p, flashStack, ItemCameraTransforms.TransformType.FIRST_PERSON_RIGHT_HAND, false);
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, lx, ly);
            GlStateManager.enableLighting();
        }

        GlStateManager.disableRescaleNormal();
        GlStateManager.popMatrix();
    }

    /** Рисует настоящую руку игрока (со скином), кисть которой стоит в точке hand (ед. модели) оружия. */
    private static void renderArm(Minecraft mc, EntityPlayerSP p, boolean right, float[] hand,
                                  float ox, float oy, float oz, float[] dir, float[] palm) {
        RenderPlayer rp = (RenderPlayer) (Object) mc.getRenderManager().getEntityRenderObject(p);
        if (rp == null) return;
        ModelPlayer model = rp.getMainModel();
        ModelRenderer arm = right ? model.bipedRightArm : model.bipedLeftArm;

        // центр торца руки (кисть) в координатах модели, блоки
        float hx = (arm.rotationPointX + 0F) / 16F, hy = (arm.rotationPointY + 12F) / 16F, hz = arm.rotationPointZ / 16F;
        if (!arm.cubeList.isEmpty()) {
            ModelBox box = arm.cubeList.get(0);
            hx = (arm.rotationPointX + (box.posX1 + box.posX2) / 2F) / 16F;
            hy = (arm.rotationPointY + box.posY2) / 16F;
            hz = (arm.rotationPointZ + (box.posZ1 + box.posZ2) / 2F) / 16F;
        }

        // ось плечо->кисть (a), ладонь (pp), правая тройка: x = ±ладонь, y = -a, z = x*y
        double[] a = norm(new double[]{dir[0], dir[1], dir[2]});
        double d = a[0] * palm[0] + a[1] * palm[1] + a[2] * palm[2];
        double[] pp = norm(new double[]{palm[0] - a[0] * d, palm[1] - a[1] * d, palm[2] - a[2] * d});
        double[] xi = right ? new double[]{-pp[0], -pp[1], -pp[2]} : pp;
        double[] yi = {-a[0], -a[1], -a[2]};
        double[] zi = {xi[1] * yi[2] - xi[2] * yi[1], xi[2] * yi[0] - xi[0] * yi[2], xi[0] * yi[1] - xi[1] * yi[0]};

        float px = SCALE * ((hand[0] + ox) / 16F - 0.5F);
        float py = SCALE * ((hand[1] + oy) / 16F - 0.5F);
        float pz = SCALE * ((hand[2] + oz) / 16F - 0.5F);

        MBUF.clear();
        MBUF.put((float) xi[0]).put((float) xi[1]).put((float) xi[2]).put(0F);
        MBUF.put((float) yi[0]).put((float) yi[1]).put((float) yi[2]).put(0F);
        MBUF.put((float) zi[0]).put((float) zi[1]).put((float) zi[2]).put(0F);
        MBUF.put(0F).put(0F).put(0F).put(1F);
        MBUF.flip();

        GlStateManager.pushMatrix();
        GlStateManager.translate(px, py, pz);
        GlStateManager.multMatrix(MBUF);
        GlStateManager.scale(ARM_SCALE, ARM_SCALE, ARM_SCALE);
        GlStateManager.translate(hx, hy, -hz);   // = -handEnd в системе сущности (x,y инвертированы)
        GlStateManager.scale(-1F, -1F, 1F);      // как при отрисовке сущности
        mc.getTextureManager().bindTexture(p.getLocationSkin());
        GlStateManager.disableCull();
        if (right) rp.renderRightArm(p); else rp.renderLeftArm(p);
        GlStateManager.enableCull();
        GlStateManager.popMatrix();
    }

    private static double[] norm(double[] v) {
        double l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        if (l < 1e-9) return new double[]{0, 1, 0};
        return new double[]{v[0] / l, v[1] / l, v[2] / l};
    }

    // =====================================================================
    //  FOV, тряска камеры, HUD
    // =====================================================================
    @SubscribeEvent
    public static void onFov(EntityViewRenderEvent.FOVModifier e) {
        float a = smooth01(lerp(prevAim, aim, (float) e.getRenderPartialTicks()));
        if (a > 0F) e.setFOV(e.getFOV() * lerp(1F, ADS_FOV_MULT, a));
    }

    @SubscribeEvent
    public static void onCamera(EntityViewRenderEvent.CameraSetup e) {
        float s = lerp(prevShake, shake, (float) e.getRenderPartialTicks());
        if (s > 0.01F) {
            e.setRoll(e.getRoll() + (RAND.nextFloat() - 0.5F) * 0.9F * s);
            e.setPitch(e.getPitch() + (RAND.nextFloat() - 0.5F) * 0.3F * s);
        }
    }

    @SubscribeEvent
    public static void onOverlayPre(RenderGameOverlayEvent.Pre e) {
        // при прицеливании ванильный перекрестие не нужно - есть мушка
        if (e.getType() == RenderGameOverlayEvent.ElementType.CROSSHAIRS && aim > 0.5F) e.setCanceled(true);
    }

    @SubscribeEvent
    public static void onOverlayPost(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.ALL) return;
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP p = mc.player;
        if (p == null || p.getHeldItemMainhand().getItem() != ModItems.AK47 || mc.gameSettings.hideGUI) return;

        ItemStack gun = p.getHeldItemMainhand();
        int ammo = ItemAK47.getAmmo(gun);
        int reserve = p.capabilities.isCreativeMode ? -1 : ItemAK47.countAmmo(p);

        String top = ItemAK47.isReloading(gun) ? I18n.format("hud.akmod.reloading") : String.valueOf(ammo);
        String bottom = reserve < 0 ? "\u221E" : "x" + reserve;
        int color = (ammo <= 5 && !ItemAK47.isReloading(gun)) ? 0xFF5555 : 0xFFFFFF;

        ScaledResolution res = e.getResolution();
        int w = res.getScaledWidth(), h = res.getScaledHeight();

        GlStateManager.pushMatrix();
        GlStateManager.scale(2F, 2F, 1F);
        int tw = mc.fontRenderer.getStringWidth(top);
        mc.fontRenderer.drawStringWithShadow(top, (w - 14) / 2F - tw, (h - 52) / 2F, color);
        GlStateManager.popMatrix();

        int bw = mc.fontRenderer.getStringWidth(bottom);
        mc.fontRenderer.drawStringWithShadow(bottom, w - 14 - bw, h - 34, 0xAAAAAA);
        String mode = "AK-47  " + I18n.format(ItemAK47.isSemi(gun) ? "hud.akmod.semi" : "hud.akmod.auto");
        mc.fontRenderer.drawStringWithShadow(mode, w - 14 - mc.fontRenderer.getStringWidth(mode), h - 24, 0x888888);
    }
}
