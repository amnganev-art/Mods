package com.akmod.proxy;

import com.akmod.client.ClientEvents;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        ClientRegistry.registerKeyBinding(ClientEvents.RELOAD);
        ClientRegistry.registerKeyBinding(ClientEvents.FIREMODE);
    }

    @Override
    public void onShot(final int burstIndex) {
        Minecraft.getMinecraft().addScheduledTask(() -> ClientEvents.onShot(burstIndex));
    }
}
