package com.akmod.net;

import com.akmod.ModItems;
import com.akmod.ModSounds;
import com.akmod.item.ItemAK47;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.item.ItemStack;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Клиент -> сервер: клавиша B - переключить авто / одиночный. */
public class PacketFireMode implements IMessage {
    @Override public void fromBytes(ByteBuf buf) {}
    @Override public void toBytes(ByteBuf buf) {}

    public static class Handler implements IMessageHandler<PacketFireMode, IMessage> {
        @Override
        public IMessage onMessage(PacketFireMode m, MessageContext ctx) {
            final EntityPlayerMP p = ctx.getServerHandler().player;
            p.getServerWorld().addScheduledTask(() -> {
                ItemStack s = p.getHeldItemMainhand();
                if (s.getItem() != ModItems.AK47) return;
                boolean semi = !ItemAK47.isSemi(s);
                ItemAK47.setSemi(s, semi);
                p.world.playSound(null, p.posX, p.posY, p.posZ, ModSounds.DRY, SoundCategory.PLAYERS, 0.6F, 1.4F);
                p.sendStatusMessage(new TextComponentTranslation(semi ? "message.akmod.mode_semi" : "message.akmod.mode_auto"), true);
            });
            return null;
        }
    }
}
